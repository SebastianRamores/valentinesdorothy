import { motion } from "framer-motion";
import { Heart } from "lucide-react";

interface GalleryCardProps {
  src: string;
  alt: string;
  caption?: string;
  rotate?: number;
}

export function GalleryCard({ src, alt, caption, rotate = 0 }: GalleryCardProps) {
  return (
    <motion.div
      whileHover={{ scale: 1.05, rotate: 0, zIndex: 10 }}
      initial={{ rotate }}
      viewport={{ once: true }}
      className="relative group cursor-pointer"
    >
      <div className="bg-white p-3 pb-8 rounded-sm shadow-lg transform transition-all duration-300 border border-gray-100">
        <div className="aspect-[4/3] overflow-hidden rounded-sm bg-gray-100 relative">
          <img 
            src={src} 
            alt={alt} 
            className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110" 
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
        </div>
        
        {caption && (
          <div className="absolute bottom-2 left-0 w-full text-center">
            <p className="font-display text-gray-600 text-lg rotate-[-1deg]">{caption}</p>
          </div>
        )}
        
        {/* Tape effect */}
        <div className="absolute -top-3 left-1/2 -translate-x-1/2 w-24 h-8 bg-white/30 backdrop-blur-sm rotate-2 shadow-sm border border-white/40" />
      </div>
      
      <div className="absolute -bottom-2 -right-2 text-primary opacity-0 group-hover:opacity-100 transition-all duration-300 transform translate-y-2 group-hover:translate-y-0">
        <Heart className="fill-current w-6 h-6" />
      </div>
    </motion.div>
  );
}
